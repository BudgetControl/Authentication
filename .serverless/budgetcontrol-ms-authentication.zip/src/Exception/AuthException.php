<?php
namespace Budgetcontrol\Authentication\Exception;

class AuthException extends \Exception
{
}
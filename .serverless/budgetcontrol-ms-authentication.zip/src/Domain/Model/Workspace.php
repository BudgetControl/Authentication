<?php 
namespace Budgetcontrol\Library\Model;

use Illuminate\Database\Eloquent\Model;

class Workspace extends Model
{

    protected $hidden = [
        'id'
    ];

}